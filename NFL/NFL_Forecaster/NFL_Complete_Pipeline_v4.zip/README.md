# NFL Public Data Warehouse & Forecasting Pipeline — v4

## Notebooks
1. `NFL_Public_Data_Warehouse.ipynb` — collects public NFL datasets into `nfl_data/`.
2. `NFL_Coaching_Data_Collection_v2.ipynb` — coaching source registry, schemas, and team tendencies.
3. `NFL_Data_Repair_and_Enrichment.ipynb` — audits aliases, retries optional data sources, derives team tendencies, and attempts public coaching-history ingestion.
4. `NFL_Analysis_and_Neural_Networks_v2.ipynb` — broad analysis, position-specific model comparisons, walk-forward helper, and forecasting templates.
5. `NFL_Player_Game_Forecasting_Pipeline.ipynb` — dedicated leakage-safe player-game regression workflow with train/validation/test seasons, training-mean and recent-player baselines, Ridge, MLP neural networks, metrics, SQL/DuckDB window-function example, and model-card exports.

## Run order
1. Run the warehouse collector.
2. Run the coaching collection notebook if desired.
3. Run the repair/enrichment notebook.
4. Inspect `nfl_data/repair/` inventory/status outputs and confirm player-level source tables are actually game-level.
5. Run the player-game forecasting notebook for one target first (for example `receiving_yards`).
6. Run the general analysis notebook for broader exploration.

All notebooks should point to the same `nfl_data/` directory. Do not overwrite or delete the existing raw data directory during an upgrade.

## Environment
Core packages: `pandas numpy pyarrow scikit-learn matplotlib joblib`. The SQL example optionally uses `duckdb`. Parquet is preferred for large feature tables; CSV is used for readable metrics and prediction exports.

## Modeling and safety checks
- One supervised row must represent one player in one game.
- Inspect duplicate `(player_id, game_id)` keys and target semantics before training.
- Feature engineering uses shifted historical stats; current-game outcomes must never enter predictors.
- Validation and test splits are chronological by whole season. Select models on validation, and report test results once.
- Compare the MLP against simple baselines; do not assume a neural network is better.
- Upcoming forecasts require a schedule-derived player pool and pregame roster/injury/role information. The historical evaluation notebook does not invent future participants.
- These notebooks have been statically checked, but must be run against your local files and inspected for schema compatibility before trusting any forecast.
